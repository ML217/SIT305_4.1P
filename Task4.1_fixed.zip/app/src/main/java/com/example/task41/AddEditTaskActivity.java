package com.example.task41;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
public class AddEditTaskActivity extends AppCompatActivity {

    private EditText editTitle, editDescription, editDueDate;
    private TaskViewModel taskViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_task);

        editTitle = findViewById(R.id.edit_title);
        editDescription = findViewById(R.id.edit_description);
        editDueDate = findViewById(R.id.edit_due_date);

        taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);

        Button saveButton = findViewById(R.id.button_save);
        saveButton.setOnClickListener(v -> {
            String title = editTitle.getText().toString();
            String description = editDescription.getText().toString();
            long dueDate = System.currentTimeMillis(); // Placeholder

            if (title.trim().isEmpty()) {
                Toast.makeText(this, "Title is required", Toast.LENGTH_SHORT).show();
                return;
            }
            Task task = new Task(title,description,dueDate);
            taskViewModel.insert(task);
            finish();
        });
    }
}