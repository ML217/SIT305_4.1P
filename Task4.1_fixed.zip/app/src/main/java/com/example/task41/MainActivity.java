package com.example.task41;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class MainActivity extends AppCompatActivity {


        private TaskViewModel taskViewModel;
        private TaskAdapter adapter; // You'll need to implement this

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            RecyclerView recyclerView = findViewById(R.id.recycler_view);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new TaskAdapter(); // Implement this
            recyclerView.setAdapter(adapter);

            TaskViewModelFactory factory = new TaskViewModelFactory(getApplication());
        taskViewModel = new ViewModelProvider(this, factory).get(TaskViewModel.class);
            taskViewModel.getAllTasks().observe(this, tasks -> adapter.setTasks(tasks));

            FloatingActionButton fab = findViewById(R.id.fab_add_task);
            fab.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, AddEditTaskActivity.class);
                startActivity(intent);
            });
        }
    }
